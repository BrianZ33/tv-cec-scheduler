const DAY_ORDER = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"];
const DAY_LABEL = { mon: "Mon", tue: "Tue", wed: "Wed", thu: "Thu", fri: "Fri", sat: "Sat", sun: "Sun" };
const ACTION_LABEL = {
  on: "Power on",
  off: "Standby",
  "active-source": "Switch to Pi",
  switch: "Switch input",
};

const toastEl = document.getElementById("toast");

function showToast(msg) {
  toastEl.textContent = msg;
  toastEl.classList.add("show");
  setTimeout(() => toastEl.classList.remove("show"), 2200);
}

function formatTime12h(hhmm) {
  const [h, m] = hhmm.split(":").map(Number);
  const period = h >= 12 ? "PM" : "AM";
  const h12 = h % 12 === 0 ? 12 : h % 12;
  return `${h12}:${String(m).padStart(2, "0")} ${period}`;
}

/* ======================================================================
   Tab navigation
   ====================================================================== */

document.querySelectorAll(".section-nav button").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".section-nav button").forEach((b) => b.classList.remove("active"));
    document.querySelectorAll(".section-view").forEach((s) => s.classList.remove("active"));
    btn.classList.add("active");
    document.getElementById(`section-${btn.dataset.section}`).classList.add("active");
    if (btn.dataset.section === "calendar") loadCalendar();
  });
});

/* ======================================================================
   Quick actions
   ====================================================================== */

document.querySelectorAll("[data-quick]").forEach((btn) => {
  btn.addEventListener("click", async () => {
    const action = btn.dataset.quick;
    btn.disabled = true;
    try {
      const res = await fetch("/api/run-now", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action }),
      });
      const data = await res.json();
      showToast(data.ok ? `${ACTION_LABEL[action]} sent` : `Failed: ${data.error}`);
    } catch (e) {
      showToast("Request failed");
    } finally {
      btn.disabled = false;
    }
  });
});

/* ======================================================================
   Recurring cycles list
   ====================================================================== */

const entriesEl = document.getElementById("entries");
const addForm = document.getElementById("add-form");
const addFormSubmit = document.getElementById("add-form-submit");
const addToggle = document.getElementById("add-toggle");
const cancelAdd = document.getElementById("cancel-add");
const actionSelect = document.getElementById("f-action");
const addrField = document.getElementById("addr-field");
const warningField = document.getElementById("warning-field");
const dayPicker = document.getElementById("day-picker");

let editingEntryId = null;

function daysLabel(days) {
  if (days.length === 7) return "Every day";
  const weekdays = ["mon", "tue", "wed", "thu", "fri"];
  const weekend = ["sat", "sun"];
  if (days.length === 5 && weekdays.every((d) => days.includes(d))) return "Weekdays";
  if (days.length === 2 && weekend.every((d) => days.includes(d))) return "Weekends";
  return days.map((d) => DAY_LABEL[d]).join(", ");
}

async function fetchEntries() {
  const res = await fetch("/api/schedule");
  const data = await res.json();
  renderEntries(data.filter((e) => e.type !== "once"));
}

function renderEntries(entries) {
  entriesEl.innerHTML = "";
  if (entries.length === 0) {
    entriesEl.innerHTML = `<div class="empty-state">No recurring cycles yet. Add one below to get started.</div>`;
    return;
  }
  entries
    .slice()
    .sort((a, b) => a.time.localeCompare(b.time))
    .forEach((entry) => {
      const div = document.createElement("div");
      div.className = "entry" + (entry.enabled ? "" : " disabled");

      const lastRun = entry.last_run
        ? `Last run: ${entry.last_run.success ? "ok" : "failed"} \u00b7 ${new Date(entry.last_run.at).toLocaleString()}`
        : "Not run yet";

      div.innerHTML = `
        <div class="entry-time">${formatTime12h(entry.time)}</div>
        <div class="entry-body">
          <div class="entry-action">
            <span class="action-dot ${entry.action}"></span>
            ${ACTION_LABEL[entry.action] || entry.action}${entry.action === "switch" && entry.addr ? ` (${entry.addr})` : ""}
            ${entry.action === "off" && entry.warning_enabled ? `<span class="warning-badge">+ warning image</span>` : ""}
          </div>
          <div class="entry-days">
            ${DAY_ORDER.filter((d) => (entry.days || []).includes(d))
              .map((d) => `<span class="day-chip active">${DAY_LABEL[d]}</span>`)
              .join("")}
          </div>
          <div class="entry-meta">${lastRun}${entry.skip_holidays ? " \u00b7 skips holidays" : ""}</div>
        </div>
        <div class="entry-controls">
          <button class="toggle ${entry.enabled ? "on" : ""}" data-id="${entry.id}" title="Enable or disable"></button>
          <button class="btn btn-small" data-edit="${entry.id}">Edit</button>
          <button class="btn btn-small btn-danger" data-delete="${entry.id}">Delete</button>
        </div>
      `;
      entriesEl.appendChild(div);
    });

  entriesEl.querySelectorAll(".toggle").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const id = btn.dataset.id;
      const enabled = !btn.classList.contains("on");
      await fetch(`/api/schedule/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ enabled }),
      });
      fetchEntries();
    });
  });

  entriesEl.querySelectorAll("[data-edit]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const entry = entries.find((e) => e.id === btn.dataset.edit);
      if (entry) populateFormForEdit(entry);
    });
  });

  entriesEl.querySelectorAll("[data-delete]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const id = btn.dataset.delete;
      await fetch(`/api/schedule/${id}`, { method: "DELETE" });
      showToast("Cycle deleted");
      if (editingEntryId === id) resetAddForm();
      fetchEntries();
    });
  });
}

function syncActionFields(select, addrEl, warnEl) {
  addrEl.style.display = select.value === "switch" ? "flex" : "none";
  if (warnEl) warnEl.style.display = select.value === "off" ? "block" : "none";
}

function resetAddForm() {
  editingEntryId = null;
  addForm.reset();
  addForm.classList.remove("open");
  addFormSubmit.textContent = "Save cycle";
  syncActionFields(actionSelect, addrField, warningField);
  document.querySelectorAll("#day-picker .day-toggle").forEach((b) => b.classList.add("active"));
}

function populateFormForEdit(entry) {
  editingEntryId = entry.id;
  document.getElementById("f-time").value = entry.time;
  actionSelect.value = entry.action;
  document.getElementById("f-addr").value = entry.addr || "";
  document.getElementById("f-warning").checked = !!entry.warning_enabled;
  document.getElementById("f-skip-holidays").checked = entry.skip_holidays !== false;
  document.querySelectorAll("#day-picker .day-toggle").forEach((b) => {
    b.classList.toggle("active", (entry.days || []).includes(b.dataset.day));
  });
  syncActionFields(actionSelect, addrField, warningField);
  addFormSubmit.textContent = "Save changes";
  addForm.classList.add("open");
  if (typeof addForm.scrollIntoView === "function") {
    addForm.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }
}

addToggle.addEventListener("click", () => {
  if (editingEntryId) {
    resetAddForm();
  }
  addForm.classList.add("open");
  syncActionFields(actionSelect, addrField, warningField);
});

cancelAdd.addEventListener("click", () => resetAddForm());

actionSelect.addEventListener("change", () => syncActionFields(actionSelect, addrField, warningField));

dayPicker.addEventListener("click", (e) => {
  if (e.target.classList.contains("day-toggle")) {
    e.target.classList.toggle("active");
  }
});

addForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const time = document.getElementById("f-time").value;
  const action = actionSelect.value;
  const addr = document.getElementById("f-addr").value;
  const days = Array.from(dayPicker.querySelectorAll(".day-toggle.active")).map((b) => b.dataset.day);
  const warningEnabled = document.getElementById("f-warning").checked;
  const skipHolidays = document.getElementById("f-skip-holidays").checked;

  if (!time) { showToast("Pick a time first"); return; }
  if (days.length === 0) { showToast("Pick at least one day"); return; }

  const payload = {
    type: "recurring", time, action, days, addr,
    warning_enabled: action === "off" ? warningEnabled : false,
    skip_holidays: skipHolidays,
  };

  if (editingEntryId) {
    await fetch(`/api/schedule/${editingEntryId}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    showToast("Cycle updated");
  } else {
    await fetch("/api/schedule", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    showToast("Cycle added");
  }

  resetAddForm();
  fetchEntries();
});

/* ======================================================================
   Calendar

   ====================================================================== */

const calGrid = document.getElementById("cal-grid");
const calWeekdaysEl = document.getElementById("cal-weekdays");
const calMonthLabel = document.getElementById("cal-month-label");
const dayDetail = document.getElementById("day-detail");
const detailDate = document.getElementById("detail-date");
const detailEntries = document.getElementById("detail-entries");
const detailHolidayToggle = document.getElementById("detail-holiday-toggle");
const detailAddOnceBtn = document.getElementById("detail-add-once");
const onceForm = document.getElementById("once-form");
const onceCancel = document.getElementById("once-cancel");
const onceActionSelect = document.getElementById("o-action");
const onceWarningField = document.getElementById("once-warning-field");

const WEEKDAY_HEADERS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

let calYear, calMonth; // 1-indexed month
let selectedDate = null;
let calendarCache = {};
let holidaysCache = [];

function initCalendarHeaders() {
  calWeekdaysEl.innerHTML = WEEKDAY_HEADERS.map((d) => `<div class="cal-weekday">${d}</div>`).join("");
}

async function loadCalendar() {
  const today = new Date();
  if (calYear === undefined) { calYear = today.getFullYear(); calMonth = today.getMonth() + 1; }
  initCalendarHeaders();
  await refreshCalendarData();
  renderCalendar();
}

async function refreshCalendarData() {
  const [calRes, holRes] = await Promise.all([
    fetch(`/api/calendar?year=${calYear}&month=${calMonth}`),
    fetch("/api/holidays"),
  ]);
  calendarCache = await calRes.json();
  holidaysCache = await holRes.json();
}

function renderCalendar() {
  const monthNames = ["January","February","March","April","May","June","July","August","September","October","November","December"];
  calMonthLabel.textContent = `${monthNames[calMonth - 1]} ${calYear}`;

  const firstOfMonth = new Date(calYear, calMonth - 1, 1);
  const startWeekday = firstOfMonth.getDay(); // 0 = Sun
  const daysInMonth = new Date(calYear, calMonth, 0).getDate();

  let html = "";
  for (let i = 0; i < startWeekday; i++) {
    html += `<div class="cal-cell empty"></div>`;
  }
  for (let day = 1; day <= daysInMonth; day++) {
    const dateStr = `${calYear}-${String(calMonth).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
    const info = calendarCache[dateStr] || { holiday: false, entries: [] };
    const dots = info.entries
      .slice(0, 6)
      .map((e) => `<span class="cal-dot ${e.action}"></span>`)
      .join("");
    const isSelected = dateStr === selectedDate;
    html += `
      <div class="cal-cell ${info.holiday ? "holiday" : ""} ${isSelected ? "selected" : ""}" data-date="${dateStr}">
        <div class="cal-daynum">${day}</div>
        <div class="cal-dots">${dots}</div>
      </div>
    `;
  }
  calGrid.innerHTML = html;

  calGrid.querySelectorAll(".cal-cell[data-date]").forEach((cell) => {
    cell.addEventListener("click", () => selectDate(cell.dataset.date));
  });

  if (selectedDate && calendarCache[selectedDate]) {
    renderDayDetail(selectedDate);
  }
}

function selectDate(dateStr) {
  selectedDate = dateStr;
  renderCalendar();
  renderDayDetail(dateStr);
}

function renderDayDetail(dateStr) {
  dayDetail.style.display = "block";
  onceForm.classList.remove("open");
  const info = calendarCache[dateStr] || { holiday: false, entries: [] };
  const d = new Date(dateStr + "T00:00:00");
  detailDate.textContent = d.toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric", year: "numeric" });

  detailHolidayToggle.textContent = info.holiday ? "Remove holiday" : "Mark as holiday";
  detailHolidayToggle.className = info.holiday ? "btn btn-small btn-danger" : "btn btn-small";
  detailHolidayToggle.onclick = async () => {
    if (info.holiday) {
      await fetch(`/api/holidays/${dateStr}`, { method: "DELETE" });
      showToast("Holiday removed");
    } else {
      await fetch("/api/holidays", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ date: dateStr }),
      });
      showToast("Marked as holiday");
    }
    await refreshCalendarData();
    renderCalendar();
    renderDayDetail(dateStr);
  };

  if (info.entries.length === 0) {
    detailEntries.innerHTML = `<div class="detail-empty">Nothing scheduled this day.</div>`;
  } else {
    detailEntries.innerHTML = info.entries
      .map((e) => `
        <div class="detail-entry">
          <span class="action-dot ${e.action}"></span>
          ${formatTime12h(e.time)} \u2014 ${ACTION_LABEL[e.action] || e.action}
          ${e.type === "once" ? " (one-time)" : ""}
          ${e.action === "off" && e.warning_enabled ? `<span class="warning-badge">+ warning</span>` : ""}
        </div>
      `)
      .join("");
  }

  detailAddOnceBtn.onclick = () => {
    onceForm.classList.add("open");
    document.getElementById("o-time").value = "";
    onceWarningField.style.display = onceActionSelect.value === "off" ? "block" : "none";
  };
}

onceCancel.addEventListener("click", () => onceForm.classList.remove("open"));

onceActionSelect.addEventListener("change", () => {
  onceWarningField.style.display = onceActionSelect.value === "off" ? "block" : "none";
});

onceForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const time = document.getElementById("o-time").value;
  const action = onceActionSelect.value;
  const warningEnabled = document.getElementById("o-warning").checked;
  if (!time) { showToast("Pick a time first"); return; }

  await fetch("/api/schedule", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      type: "once", time, action, date: selectedDate,
      warning_enabled: action === "off" ? warningEnabled : false,
      skip_holidays: true,
    }),
  });

  onceForm.reset();
  onceForm.classList.remove("open");
  showToast("One-time event added");
  await refreshCalendarData();
  renderCalendar();
  renderDayDetail(selectedDate);
});

document.getElementById("cal-prev").addEventListener("click", async () => {
  calMonth -= 1;
  if (calMonth < 1) { calMonth = 12; calYear -= 1; }
  await refreshCalendarData();
  renderCalendar();
});

document.getElementById("cal-next").addEventListener("click", async () => {
  calMonth += 1;
  if (calMonth > 12) { calMonth = 1; calYear += 1; }
  await refreshCalendarData();
  renderCalendar();
});

/* ======================================================================
   Holidays list
   ====================================================================== */

const holidayListEl = document.getElementById("holiday-list");
const holidayForm = document.getElementById("holiday-form");

async function fetchHolidays() {
  const res = await fetch("/api/holidays");
  const data = await res.json();
  renderHolidays(data);
}

function renderHolidays(holidays) {
  if (holidays.length === 0) {
    holidayListEl.innerHTML = `<div class="empty-state">No holidays added yet.</div>`;
    return;
  }
  holidayListEl.innerHTML = holidays
    .map((h) => {
      const d = new Date(h.date + "T00:00:00");
      const label = d.toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric", year: "numeric" });
      return `
        <div class="holiday-row">
          <span class="holiday-date">${label}</span>
          <span class="holiday-label">${h.label || ""}</span>
          <button class="btn btn-small btn-danger" data-remove-holiday="${h.date}">Remove</button>
        </div>
      `;
    })
    .join("");

  holidayListEl.querySelectorAll("[data-remove-holiday]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      await fetch(`/api/holidays/${btn.dataset.removeHoliday}`, { method: "DELETE" });
      showToast("Holiday removed");
      fetchHolidays();
    });
  });
}

holidayForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const start = document.getElementById("h-start").value;
  const end = document.getElementById("h-end").value;
  const label = document.getElementById("h-label").value;
  if (!start) { showToast("Pick a start date"); return; }

  const res = await fetch("/api/holidays", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ start, end: end || start, label }),
  });

  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    showToast(data.error || "Failed to add holiday");
    return;
  }

  holidayForm.reset();
  showToast("Holiday added");
  fetchHolidays();
});

/* ======================================================================
   Settings (warning image + duration)
   ====================================================================== */

const imagePreview = document.getElementById("image-preview");
const settingsFile = document.getElementById("settings-file");
const settingsDuration = document.getElementById("settings-duration");
const settingsSkipIfOff = document.getElementById("settings-skip-if-off");
const settingsSave = document.getElementById("settings-save");

async function fetchSettings() {
  const res = await fetch("/api/settings");
  const data = await res.json();
  settingsDuration.value = data.warning_duration_seconds;
  settingsSkipIfOff.checked = data.skip_warning_if_tv_off !== false;
  if (data.warning_image) {
    imagePreview.innerHTML = `<img src="/static/uploads/${data.warning_image}?t=${Date.now()}" alt="Warning image">`;
  } else {
    imagePreview.innerHTML = `<div class="placeholder">No image set</div>`;
  }
}

settingsSave.addEventListener("click", async () => {
  settingsSave.disabled = true;
  try {
    if (settingsFile.files.length > 0) {
      const formData = new FormData();
      formData.append("image", settingsFile.files[0]);
      const res = await fetch("/api/settings/image", { method: "POST", body: formData });
      const data = await res.json();
      if (!res.ok) { showToast(`Failed: ${data.error}`); return; }
    }
    const duration = parseInt(settingsDuration.value, 10);
    if (!Number.isFinite(duration) || duration < 1) { showToast("Enter a valid number of seconds"); return; }
    await fetch("/api/settings", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        warning_duration_seconds: duration,
        skip_warning_if_tv_off: settingsSkipIfOff.checked,
      }),
    });
    settingsFile.value = "";
    showToast("Settings saved");
    fetchSettings();
  } finally {
    settingsSave.disabled = false;
  }
});

/* ======================================================================
   Init
   ====================================================================== */

fetchEntries();
fetchSettings();
