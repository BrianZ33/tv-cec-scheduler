#!/bin/bash
# Builds tv-cec-scheduler_<version>.deb from this repo's source files.
# Run from the repo root: ./packaging/build-deb.sh
set -e

VERSION="1.1.0-1"
PKG="tv-cec-scheduler_${VERSION}"
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD_DIR="/tmp/${PKG}-build"

rm -rf "$BUILD_DIR"
mkdir -p "$BUILD_DIR/DEBIAN"
mkdir -p "$BUILD_DIR/opt/tv-cec-scheduler/templates"
mkdir -p "$BUILD_DIR/opt/tv-cec-scheduler/static/uploads"
mkdir -p "$BUILD_DIR/opt/tv-cec-scheduler/systemd-extras"
mkdir -p "$BUILD_DIR/etc/systemd/system"
mkdir -p "$BUILD_DIR/usr/share/doc/tv-cec-scheduler"

cp "$REPO_ROOT"/packaging/DEBIAN/* "$BUILD_DIR/DEBIAN/"

cp "$REPO_ROOT"/{app.py,tv_cec.py,display_image.py,holidays_store.py,schedule_store.py,settings_store.py,requirements.txt,README.md} \
   "$BUILD_DIR/opt/tv-cec-scheduler/"
cp "$REPO_ROOT/templates/index.html" "$BUILD_DIR/opt/tv-cec-scheduler/templates/"
cp "$REPO_ROOT"/static/{app.js,style.css} "$BUILD_DIR/opt/tv-cec-scheduler/static/"
touch "$BUILD_DIR/opt/tv-cec-scheduler/static/uploads/.gitkeep"

cp "$REPO_ROOT"/{tv-off.service,tv-off.timer,tv-morning.service,tv-morning.timer,boot-splash.service,blank-screen-boot.service} \
   "$BUILD_DIR/opt/tv-cec-scheduler/systemd-extras/"

cp "$REPO_ROOT/tv-cec-web.service" "$BUILD_DIR/etc/systemd/system/"
cp "$REPO_ROOT/README.md" "$BUILD_DIR/usr/share/doc/tv-cec-scheduler/"

chmod 755 "$BUILD_DIR"/DEBIAN/{postinst,prerm,postrm}
chmod 644 "$BUILD_DIR/DEBIAN/control"
chmod +x "$BUILD_DIR/opt/tv-cec-scheduler/tv_cec.py"

dpkg-deb --build --root-owner-group "$BUILD_DIR" "${REPO_ROOT}/${PKG}.deb"

echo ""
echo "Built: ${REPO_ROOT}/${PKG}.deb"
echo "Install with: sudo apt install ./${PKG}.deb"
